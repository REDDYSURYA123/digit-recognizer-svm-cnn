# Digit Recognizer: SVM vs CNN — Mobile, PWA, Guarded Feedback & UI Upgrade

An incremental upgrade to **Digit Recognizer: SVM vs CNN** that preserves the existing CORS MNIST pipeline, Web Worker SMO SVM, TensorFlow.js CNN, 0–100 multi-digit segmentation, Ensemble mode, and Model Comparison views while adding responsive mobile/PC tab navigation, offline PWA installability, IndexedDB-backed model versioning with accuracy-guarded feedback retraining, comprehensive reset workflows, and an Indigo/Violet + Teal visual refresh.

## User Review & Critical Decisions

> [!IMPORTANT]
> Confirmed Phase 1 architecture and UX preferences are locked into this plan alongside all four upgrade pillars from the specification.

- **Confirmed — Adaptive Landing Tab**: Launches directly into the **Predict** tab when saved models are restored from IndexedDB, and opens on the **Train** tab on first run when no trained models exist yet.
- **Confirmed — Dual Feedback Entry Flow**: Users can submit digit corrections directly via a compact quick-feedback bar below the **Predict** result card as well as inspect, validate, and trigger guarded retraining inside the dedicated **Feedback** tab.
- **Confirmed — IndexedDB Snapshot & Feedback Storage**: Feedback samples, user-rated accuracy counters, model version history, and untouched **Baseline** SVM/CNN snapshots are persisted in IndexedDB to avoid `localStorage` 5MB quota limits.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the single-page workbench into a mobile-ready, installable offline PWA organized into six icon-labeled tabs (**Train**, **Predict**, **Compare**, **Feedback**, **Settings**, **About**). Users draw numbers (`0–100`), rate or correct predictions, retrain SVM and CNN safely with accuracy-drop protection and automatic rollback, inspect version history, and manage data resets.
- **Target Audience**: Learners and developers testing classical vs. deep handwriting recognition across desktop and touch devices, including offline classroom or demo environments.
- **Key Value**: Prevents catastrophic forgetting and accuracy collapse when fine-tuning on user feedback by enforcing strict dataset caps, low-LR CNN fine-tuning, fixed test-set validation, and automatic rollback to prior or baseline snapshots.

---

## 2. User Experience & Visual Design

### Responsive Navigation & Touch Ergonomics
- **Mobile (`< 640px`)**: Single-column vertical layout with a compact sticky top bar (app title, offline/accuracy indicator, theme toggle, install prompt) and a fixed bottom tab bar (`6` icon+label tabs: **Train**, **Predict**, **Compare**, **Feedback**, **Settings**, **About**) featuring `>= 44px` touch hitboxes and zero horizontal scrolling.
- **Tablet & Desktop (`>= 640px`)**: Top horizontal tab bar with icons above a balanced two-column workspace for training controls, live charts, and multi-digit prediction results.
- **Mobile Canvas & Training Defaults**: The `560×280` internal canvas scales smoothly to container width (`aspect-[2/1]`) with `touch-action: none` and pointer events so touch drawing never scrolls the page. On mobile viewports, initial defaults select lighter parameters (SVM `1,000` samples, CNN `3` epochs) paired with a `"May be slow on phones"` hint.

### Visual Identity & Theme (Indigo / Violet + Teal)
- **Aesthetic Direction**: Refined ML Studio Workbench with `rounded-2xl` cards, soft layered elevation shadows, subtle indigo-to-violet gradient section headers, and smooth transitions on tab switches and prediction reveals.
- **Color Palette (60-30-10)**:
  - *Dark Mode (Default)*: Deep slate-indigo canvas (`#090B14`), elevated indigo-tinted dark cards (`#111526`) with subtle `1px` `#1E243D` borders, crisp `#F1F5F9` text, primary **Indigo/Violet** (`#6366F1` / `#7C3AED`) for CTAs, active tabs, and SVM highlights, and **Teal** (`#14B8A6`) accents for CNN metrics, progress highlights, and ensemble confirmations.
  - *Light Mode (Toggled)*: Crisp cool alabaster canvas (`#F8FAFC`), pure white cards (`#FFFFFF`) with `#E2E8F0` borders, deep indigo (`#4F46E5`) primary controls, and teal (`#0D9488`) accents.
- **Highlighted Prediction Card & Feedback**:
  - Assembled `0–100` predicted number appears in a large glowing Indigo/Teal result card with horizontal confidence progress bars for every segmented digit and a compact quick-feedback bar right below.
  - Skeleton placeholders render during initial IndexedDB/CDN hydration; a persistent warning banner appears across the top workspace if any active model's test accuracy drops below `90%`.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Unified IndexedDB Store for Models, Snapshots & Feedback**:
  - *Chosen Approach*: Store all SVM binary/PCA snapshots, CNN TensorFlow.js weights (via IndexedDB IO handler per version key), feedback samples, user-rated accuracy counters, and version metadata in a dedicated IndexedDB database, leaving only lightweight theme preference in `localStorage`.
  - *Why*: Storing multiple CNN + SVM snapshots (Baseline + version history) easily exceeds `localStorage`'s 5MB ceiling; IndexedDB handles tens of megabytes reliably offline.
  - *Alternatives Considered*: Keeping only the latest model in `localStorage` (cannot support version history + Baseline restore).

- **Decision 2 — Accuracy-Guarded Feedback Retraining & Rollback**:
  - *Chosen Approach*: Keep the `1,000`-sample MNIST test split strictly immutable. Combine original MNIST training data with capped feedback (`<= 10%` of training subset size, duplicating each unique feedback digit at most `3×` with slight 1px shift/rotation augmentation). Fine-tune CNN from current weights at `lr = 0.0001` for `2` epochs; retrain SVM in its Web Worker on the combined set. Evaluate on the fixed test set and commit only if `accuracy >= 90%` and `drop <= 1%` vs. the pre-retrain snapshot; otherwise auto-rollback and display `"Retraining rejected: accuracy would drop to X%. Previous model kept."`
  - *Why*: Protects model generalization against small, noisy, or skewed user feedback batches while still adapting to personal handwriting.
  - *Alternatives Considered*: Unchecked incremental updates (rapidly degrades MNIST accuracy below 80%).

- **Decision 3 — Offline PWA via `vite-plugin-pwa` & Workbox Runtime Caching**:
  - *Chosen Approach*: Configure `vite-plugin-pwa` with a complete Web App Manifest, custom `192×192`, `512×512`, maskable `512×512`, and `180×180` Apple touch PNG icons, `CacheFirst` rules for Google Fonts and jsDelivr TensorFlow.js CDN, and `StaleWhileRevalidate`/`CacheFirst` for the Google Cloud Storage MNIST sprite & labels, plus an in-app **Install App** button and **Offline Mode** indicator.
  - *Why*: Ensures the app boots, loads MNIST data, and runs SVM/CNN inference completely offline after the first load.
  - *Alternatives Considered*: Hand-written service worker without Workbox precaching (fragile hashed Vite bundle caching).

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                PWA Shell & Responsive 6-Tab UI (Indigo/Teal)              │
│   [Train]   [Predict]   [Compare]   [Feedback]   [Settings]   [About]     │
└──────┬──────────┬───────────┬───────────┬─────────────┬───────────────────┘
       │          │           │           │             │
       ▼          │           ▼           ▼             ▼
┌──────────────┐  │   ┌─────────────┐  ┌──────────────────────────────┐
│ Model Engine │  │   │ Comparison  │  │ Guarded Feedback & Versioning│
│ - SVM Worker │  │   │ & Metrics   │  │ - Digit Count & 0-9 Validator│
│ - TF.js CNN  │  │   │ - 10x10 CM  │  │ - Duplicate Hash Detector    │
│ - Ensemble   │  │   │ - Bar Chart │  │ - 10% Cap + <=3x Augment     │
└──────┬───────┘  │   └─────────────┘  │ - >=90% & <=1% Drop Guard    │
       │          │                    └──────────────┬───────────────┘
       │          ▼                                   │
       │   ┌──────────────────────────┐               │
       │   │ 560x280 Pointer Canvas   │               │
       │   │ - touch-action: none     │               │
       │   │ - Connected-Comp Segment │               │
       │   │ - LeCun 28x28 Normalize  │               │
       │   └──────────────────────────┘               │
       ▼                                              ▼
┌───────────────────────────────────────────────────────────────────────────┐
│            IndexedDB Persistence & Workbox Service Worker Cache           │
│  - Baseline & Versioned SVM/CNN Snapshots   - Feedback & Accuracy Stats   │
│  - Offline Precached Bundle, TF.js CDN, MNIST Sprite & Labels             │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **IndexedDB Stores**:
  - `modelVersions`: Versioned SVM and CNN snapshots (`versionId`, `modelType`, `label` e.g. `"Baseline"` / `"v2 · Feedback"`, `createdAt`, `accuracy`, `config`, serialized SVM payload or IndexedDB CNN model URI).
  - `feedbackSamples`: Validated `(pixels28, label, hash, createdAt)` records plus `userRatedStats` (`totalRated`, `correctCount`).
  - `accuracyLogs`: Timestamped history of training/retraining events and before/after accuracy deltas.
- **Fixed Evaluation Benchmark**:
  - `testImages` (`1,000 × 784`) and `testLabels` (`1,000`) remain read-only in memory across the entire session and are never mutated by feedback or augmentation.

### Interactive Component & State Mapping
- **Predict Tab -> Multi-Digit Canvas & Quick Feedback**: Pointer strokes or uploaded images segment left-to-right into `28×28` inputs, evaluate via SVM, CNN, or Ensemble, render the glowing result card + confidence bars, and expose a quick **"Mark Right / Correct Number"** bar wired into the Feedback store.
- **Feedback Tab -> Validation & Guarded Retrain**: Lists saved feedback thumbnails, flags duplicates, displays user-rated accuracy stats, and triggers **"Retrain with feedback"**. Shows the Before vs. After accuracy comparison card, rollback alerts if rejected, and the version history list with **"Restore this version"** and **"Restore Baseline"** controls.
- **Settings Tab -> Safe Reset Dialogs**: Provides four isolated reset actions (**Clear feedback data**, **Reset accuracy stats**, **Restore baseline models**, **Factory reset**), each opening an explicit confirmation modal detailing what will be erased before executing, showing a toast confirmation, and returning to the **Train** tab.
